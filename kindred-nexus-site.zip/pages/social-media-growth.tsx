import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export default function SocialMediaGrowth() {
  return (
    <div className="min-h-screen bg-[#0d1b1e] text-white p-6">
      <motion.div
        initial={{ opacity: 0, y: -40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-3xl mx-auto text-center"
      >
        <h1 className="text-4xl font-bold mb-6 text-gray-100">Social Media Growth</h1>
        <p className="text-lg text-gray-300 mb-12">
          Social presence is no longer optional — it's currency. We develop brand personas, craft algorithm-friendly content, and create movement where your audience already lives.
          We don't chase trends — we define them.
        </p>

        <Button className="bg-maroon-700 hover:bg-maroon-800 text-white text-lg px-8 py-4 rounded-xl">
          Request a Private Consultation
        </Button>
      </motion.div>
    </div>
  );
}
