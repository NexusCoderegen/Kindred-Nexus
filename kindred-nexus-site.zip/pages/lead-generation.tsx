import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export default function LeadGeneration() {
  return (
    <div className="min-h-screen bg-[#0d1b1e] text-white p-6">
      <motion.div
        initial={{ opacity: 0, y: -40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-3xl mx-auto text-center"
      >
        <h1 className="text-4xl font-bold mb-6 text-gray-100">Lead Generation</h1>
        <p className="text-lg text-gray-300 mb-12">
          We engineer demand. Our lead systems blend data, instinct, and frictionless user experience — guiding the right people to the right place at the right time.
          Numbers follow, but we start with intent.
        </p>

        <Button className="bg-maroon-700 hover:bg-maroon-800 text-white text-lg px-8 py-4 rounded-xl">
          Request a Private Consultation
        </Button>
      </motion.div>
    </div>
  );
}
