import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export default function SEODomination() {
  return (
    <div className="min-h-screen bg-[#0d1b1e] text-white p-6">
      <motion.div
        initial={{ opacity: 0, y: -40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-3xl mx-auto text-center"
      >
        <h1 className="text-4xl font-bold mb-6 text-gray-100">SEO Domination</h1>
        <p className="text-lg text-gray-300 mb-12">
          Our SEO approach is rooted in layered strategy — a balance between what search engines value and what your audience needs.
          We operate in silence, engineer with intent, and execute with precision. Visibility isn't the goal. Authority is.
        </p>

        <Button className="bg-maroon-700 hover:bg-maroon-800 text-white text-lg px-8 py-4 rounded-xl">
          Request a Private Consultation
        </Button>
      </motion.div>
    </div>
  );
}
